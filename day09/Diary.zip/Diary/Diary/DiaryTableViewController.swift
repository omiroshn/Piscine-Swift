//
//  DiaryTableViewController.swift
//  Diary
//
//  Created by Lesha Miroshnik on 4/13/19.
//  Copyright © 2019 Lesha Miroshnik. All rights reserved.
//

import UIKit
import omiroshn2019

class DiaryTableViewController: UITableViewController {

    var theArticles: [Article] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let theLanguage = Locale.preferredLanguages.first else {
            return
        }
        if theLanguage == "uk-US" {
            title = "Мій щоденник"
        } else if theLanguage == "ru-US" {
            title = "Мой дневник"
        } else {
            title = "My Diary"
        }
//        navigationItem.hidesBackButton = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        guard let theLanguage = Locale.preferredLanguages.first else {
            return
        }
        theArticles = ArticleManagerController.shared.getArticles(withLang: theLanguage)
        tableView.reloadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }

    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return theArticles.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "diaryCell", for: indexPath) as! DiaryTableViewCell
        
        let theDateFormatter = DateFormatter()
        theDateFormatter.dateFormat = "yyyy-MM-dd HH:mm"
        
        cell.content.text = theArticles[indexPath.row].content
        cell.creationDate.text = theDateFormatter.string(from: theArticles[indexPath.row].creationDate! as Date)
        cell.modificationDate.text = theDateFormatter.string(from: theArticles[indexPath.row].modificationDate! as Date)
        cell.diaryImageView.image = UIImage(data: theArticles[indexPath.row].image! as Data)
        cell.titleLabel.text = theArticles[indexPath.row].title

        return cell
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let theArticle = theArticles[indexPath.row]
            DispatchQueue.main.async {
                ArticleManagerController.shared.removeArticle(anArticle: theArticle)
                ArticleManagerController.shared.save()
            }
            theArticles.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let theDestinationViewController = AddArticleViewController()
//        theDestinationViewController.article = theArticles[indexPath.row]
//        show(theDestinationViewController, sender: self)
    }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }

}
