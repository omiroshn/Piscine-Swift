//
//  ArticleManagerController.swift
//  Diary
//
//  Created by Lesha Miroshnik on 4/13/19.
//  Copyright © 2019 Lesha Miroshnik. All rights reserved.
//

import Foundation
import omiroshn2019

class ArticleManagerController {
    static let shared = ArticleManager()
}
