//
//  PasswordViewController.swift
//  Diary
//
//  Created by Lesha Miroshnik on 4/13/19.
//  Copyright © 2019 Lesha Miroshnik. All rights reserved.
//

import UIKit

class PasswordViewController: UIViewController {
    
    let aPassword = "admin"
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func loginButton(_ sender: UIButton) {
        guard let password = passwordTextField.text else {return}
        if password == self.aPassword {
            self.performSegue(withIdentifier: "toTableFromPassword", sender: self)
        } else {
            self.showAllert(withTitle: "Error", withMessage: "Wrong password")
        }
    }
    
    func showAllert(withTitle title: String, withMessage msg: String) {
        let ac = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Close", style: .default))
        self.present(ac, animated: true)
    }

}
