//
//  ViewController.swift
//  Diary
//
//  Created by Lesha Miroshnik on 4/13/19.
//  Copyright © 2019 Lesha Miroshnik. All rights reserved.
//

import UIKit
import omiroshn2019
import LocalAuthentication

class FaceIdViewController: UIViewController {

    var theArticleManager = ArticleManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let theFirstArticle = theArticleManager.newArticle()
//        theFirstArticle.title = "Article 1"
//        theFirstArticle.content = "Hello world"
//        theFirstArticle.creationDate = NSDate()
//        theFirstArticle.modificationDate = NSDate()
//        theFirstArticle.language = "ua"
//        theFirstArticle.image = 
//        theArticleManager.save()
//        
//        let theSecondArticle = theArticleManager.newArticle()
//        theSecondArticle.title = "Article 2"
//        theSecondArticle.content = "Yoyoyoyo cheatera"
//        theSecondArticle.creationDate = NSDate()
//        theSecondArticle.modificationDate = NSDate()
//        theSecondArticle.language = "en"
//        theArticleManager.save()
//        
//        let theArticles = theArticleManager.getAllArticles()
//        print(theArticles)
//        print(theArticleManager.getArticles(containString: "rld"))
//        print(theArticleManager.getArticles(withLang: "en"))
//        for article in theArticles {
//            theArticleManager.removeArticle(anArticle: article)
//        }
//        print(theArticleManager.getArticles(withLang: "uk"))
    }
    
    var passwordPassed: Bool?
    
    @IBAction func faceIDButton(_ sender: UIButton) {
        let context = LAContext()
        let reason = "Use your finder to enter"
        
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil) {
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { (wasCorrect, error) in
                DispatchQueue.main.async {
                    if wasCorrect {
                        print("Correct")
                        self.performSegue(withIdentifier: "toTableFromFaceId", sender: self)
                    } else {
                        self.performSegue(withIdentifier: "password", sender: self)
                    }
                }
            }
        } else {
            self.showAllert(withTitle: "Biometry unavailable", withMessage: "Your device is not configured for biometric authentication.")
        }
    }
    
    func showAllert(withTitle title: String, withMessage msg: String) {
        let ac = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Close", style: .default))
        self.present(ac, animated: true)
    }
    
}

